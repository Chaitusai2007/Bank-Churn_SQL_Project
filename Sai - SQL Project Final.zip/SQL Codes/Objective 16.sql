SELECT 
    CASE
        WHEN age BETWEEN 18 AND 30 THEN 'Adult'
        WHEN age BETWEEN 31 AND 50 THEN 'Middle-Aged'
        ELSE 'Old-Aged'
    END AS age_brackets,
    AVG(tenure) AS avg_tenure
FROM
    customerinfosql c
        JOIN
    bank_churnsql b ON c.CustomerId = b.CustomerId
WHERE
    b.exited = 1
GROUP BY age_brackets
ORDER BY age_brackets;
