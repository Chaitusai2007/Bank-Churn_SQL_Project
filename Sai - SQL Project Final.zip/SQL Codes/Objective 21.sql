SELECT g.GeographyLocation, COUNT(b.CustomerId) AS num_exited_people, AVG(b.CustomerId) AS avg_balance
FROM bank_churnsql b
JOIN customerinfosql c ON b.CustomerId = c.CustomerId
JOIN geography g ON c.GeographyID = g.GeographyID
WHERE b.Exited = 1
GROUP BY g.GeographyLocation
ORDER BY Count(b.CustomerId)desc;
