WITH credit_score_segments AS (
  SELECT
    customerid, isactivemember,
   CASE
      WHEN creditscore between 800 and 850 THEN 'Excellent'
      WHEN creditscore between 740 and 799 THEN 'Very Good'
      WHEN creditscore between 670 and 739 THEN 'Good'
      WHEN creditscore between 580 and 669 THEN 'Fair'
      ELSE 'Poor'
    END AS credit_score_segment
  FROM bank_churnsql
)
SELECT
  credit_score_segment,
  AVG(CASE WHEN isactivemember = 0 THEN 0 ELSE 1 END) AS exit_rate
FROM credit_score_segments
GROUP BY credit_score_segment
ORDER BY exit_rate DESC
LIMIT 1;
