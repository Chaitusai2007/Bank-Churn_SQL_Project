WITH ActiveAccounts AS (
    SELECT CustomerId,COUNT(*) AS ActiveAccounts
    FROM Bank_Churnsql
    WHERE IsActiveMember = 1
    GROUP BY customerId
)
SELECT CASE WHEN c.GenderID = 1 THEN 'Male' ELSE 'Female' END AS Gender,
    COUNT(aa.CustomerId) AS ActiveAccounts, AVG(c.EstimatedSalary) AS AvgSalary
FROM customerinfosql c
LEFT JOIN ActiveAccounts aa ON c.CustomerId = aa.CustomerId
GROUP BY Gender
ORDER BY AvgSalary DESC;
