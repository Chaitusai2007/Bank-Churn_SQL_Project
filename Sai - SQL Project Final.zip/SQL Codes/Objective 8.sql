SELECT 
    g.geographylocation, COUNT(b.customerId) AS active_customers
FROM
    geography g
        JOIN
    customerinfosql c ON g.GeographyID = c.GeographyID
        JOIN
    bank_churnsql b ON c.CustomerId = b.CustomerId
WHERE
    b.tenure > 5
GROUP BY g.GeographyLocation
ORDER BY active_customers DESC
LIMIT 1;
