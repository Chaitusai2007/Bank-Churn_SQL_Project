SELECT 
    g.GeographyLocation,
    CASE
        WHEN EstimatedSalary < 50000 THEN 'Low'
        WHEN EstimatedSalary < 100000 THEN 'Medium'
        ELSE 'High'
    END AS income_segment,
    CASE
        WHEN c.genderid = 1 THEN 'Male'
        ELSE 'Female'
    END AS gender, age,
    COUNT(c.CustomerId) AS number_of_customers
FROM customerinfosql c
        JOIN
    geography g ON c.geographyid = c.geographyid
GROUP BY income_segment , g.geographylocation , gender,age
ORDER BY g.GeographyLocation,age;
