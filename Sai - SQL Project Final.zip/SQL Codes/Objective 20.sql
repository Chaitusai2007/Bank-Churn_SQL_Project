WITH info AS (
SELECT 
    CASE
        WHEN c.Age BETWEEN 18 AND 30 THEN 'Adult'
        WHEN c.Age BETWEEN 31 AND 50 THEN 'Middle-Aged'
        ELSE 'Old-Aged'
    END AS age_brackets,
    count(c.CustomerId) AS HasCreditCard
FROM customerinfosql c JOIN bank_churnsql b ON c.CustomerId=b.CustomerId
WHERE HasCrCard = 1
GROUP BY age_brackets)
SELECT *
FROM info
WHERE HasCreditCard < (SELECT AVG(HasCreditCard) FROM info);
