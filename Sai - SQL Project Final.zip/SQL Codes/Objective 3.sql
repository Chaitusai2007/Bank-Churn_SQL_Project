SELECT AVG(NumOfProducts) AS avg_products_with_credit_card
FROM bank_churnsql
WHERE HasCrCard = 1; 