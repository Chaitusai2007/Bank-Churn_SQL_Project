SELECT 
    c.customerid,
    c.surname,
    CASE
        WHEN b.isactivemember = 1 THEN 'Active'
        ELSE 'InActive'
    END AS activity_status
FROM
    customerinfosql c
        JOIN
    bank_churnsql b ON c.customerid = b.customerid
WHERE
    c.surname REGEXP 'on$'
ORDER BY c.surname;
