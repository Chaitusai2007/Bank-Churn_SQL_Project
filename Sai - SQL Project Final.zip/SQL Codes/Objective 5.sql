SELECT Exited,
AVG(CreditScore) AS avg_credit_score
FROM bank_churnsql
GROUP BY Exited;
