use capstone;
SELECT customerid, surname, estimatedsalary
FROM customerinfosql
WHERE EXTRACT(QUARTER FROM Bank_DOJ) = 4
ORDER BY estimatedsalary DESC
LIMIT 5;

