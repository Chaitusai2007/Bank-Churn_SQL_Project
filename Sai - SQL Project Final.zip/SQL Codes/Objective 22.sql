use capstone;
SELECT 
    ci.CustomerID, 
    ci.Surname, 
    CONCAT(ci.CustomerID, '_', ci.Surname) AS Customer_Surname
FROM 
    customerinfosql ci
join bank_churnsql bc
on ci.CustomerID = bc.CustomerID;