ALTER TABLE bank_churnsql
RENAME COLUMN HasCrCard TO Has_creditcard;
