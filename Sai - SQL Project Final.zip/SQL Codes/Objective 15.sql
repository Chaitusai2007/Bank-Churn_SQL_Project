WITH geographic_avg_salary AS (
SELECT g.geographylocation,
    CASE
        WHEN c.genderid = 1 THEN 'Male'
        ELSE 'Female'
    END AS gender,
    AVG(c.estimatedsalary) AS avg_salary
FROM
    customerinfosql c
JOIN geography g ON c.GeographyID = g.GeographyID
GROUP BY g.Geographylocation,c.GenderID
ORDER BY g.GeographyLocation)

SELECT *, RANK() OVER(PARTITION BY geographylocation ORDER BY avg_salary DESC) AS `rank`
FROM geographic_avg_salary;
