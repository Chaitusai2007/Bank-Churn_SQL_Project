SELECT CustomerId,CreditScore,Tenure,Balance,NumOfProducts,HasCrCard,IsActiveMember,
    CASE
        WHEN Exited = 0 THEN 'Retain'
        ELSE 'Exit'
    END AS ExitCategory
FROM
    bank_churnsql;
